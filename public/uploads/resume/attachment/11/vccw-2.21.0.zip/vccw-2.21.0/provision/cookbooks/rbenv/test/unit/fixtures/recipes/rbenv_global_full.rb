rbenv_global "9.1.2" do
  user      "claire"
  root_path "/mnt/roobies"
  action    :create
end
