depends 'yum'
depends 'mysql'
depends 'php'
depends 'apache2'
