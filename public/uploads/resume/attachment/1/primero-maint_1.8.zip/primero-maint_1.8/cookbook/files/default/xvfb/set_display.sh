#!/bin/bash

export DISPLAY=:10
