NAMES RESOURCES
===============

These lists of names have been taken from the next resources:

Arabic names:
http://www.firdaous.com/en/?11-a
http://www.sudairy.com/arabic/masc.html

Arabic last names:
http://meetmylastname.com/prd/articles/55/arabic-last-names/

English names:
http://names.mongabay.com/data/1000.html

English surnames:
http://names.mongabay.com/most_common_surnames.htm

Spanish names:
http://embarazoyparto.about.com/od/PreparateParaLaLlegadaDelBebe/a/Los-200-Nombres-De-Bebe-Mas-Populares-En-Espana.htm
http://espanol.babycenter.com/a4600097/los-nombres-m%C3%A1s-populares-en-espa%C3%B1a-en-las-%C3%BAltimas-d%C3%A9cadas

Spanish last names:
http://es.wikipedia.org/wiki/Anexo:Apellidos_m%C3%A1s_comunes_en_Espa%C3%B1a_e_Hispanoam%C3%A9rica#Espa.C3.B1a
http://es.wikipedia.org/wiki/Anexo:Apellidos_compuestos_alaveses

Swahili names:
http://www.top-100-baby-names-search.com/swahili-baby-names.html
