module Primero
  class Application
    VERSION = "1.8.7"
  end
end
