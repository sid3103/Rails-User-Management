# Uncomment and enter your api_key if you're using hoptoad.
# Chef will remove this and symlink to shared/config/initializers/hoptoad.rb.
# HoptoadNotifier.configure do |config|
#   config.api_key = PUT YOUR API KEY STRING HERE
# end
