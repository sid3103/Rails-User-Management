API Controllers
===============

Part of the old RapidFTR API controllers have been merged with the other
controllers in the project (primarily the `RecordActions` controller
concern).  Some of the old functionality has not been reimplemented due to the
lack of mobile device support.  Also missing from the new API is attachment
handling.  If you wish to see the old API code, look at the tag `v1.0.0.20.1`
for the latest before it was deleted (it departs very little from RapidFTR
as of the beginning of the project anyway).
