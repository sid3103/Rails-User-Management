class IncidentMediaController < ApplicationController
  @model_class = Incident

  include MediaActions

end
