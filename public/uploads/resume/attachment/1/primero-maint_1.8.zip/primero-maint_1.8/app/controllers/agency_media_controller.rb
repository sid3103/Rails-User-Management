class AgencyMediaController < ActionController::Base

  include AgencyLogos

end
