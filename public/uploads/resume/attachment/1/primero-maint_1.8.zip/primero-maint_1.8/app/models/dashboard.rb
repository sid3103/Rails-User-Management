class Dashboard
  #TODO - refactor dashboard logic
  #TODO - move dashboard logic from home controller to this model
  #TODO - This is here for now to help drive the Permissions logic
end