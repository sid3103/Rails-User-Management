class MobileDbKey < CouchRest::Model::Base
  use_database :mobile_db_key

  include PrimeroModel

  property :imei
  property :db_key

  design

  design :by_imei do
    view :by_imei,
            :map => "function(doc) {
                if ((doc['couchrest-type'] == 'MobileDbKey') && doc['imei'])
               {
                  emit(doc['imei'], null);
               }
            }"
  end

  def self.find_or_create_by_imei(imei)
     mobile_db_key = MobileDbKey.by_imei(:key => imei).first
     mobile_db_key.nil? ? MobileDbKey.create(:imei => imei, :db_key => SecureRandom.hex(8)) : mobile_db_key
  end

end
