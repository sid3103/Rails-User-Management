module Accessible
 
end