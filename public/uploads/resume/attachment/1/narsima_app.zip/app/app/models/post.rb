class Post < ApplicationRecord
	has_many :resumes
end
